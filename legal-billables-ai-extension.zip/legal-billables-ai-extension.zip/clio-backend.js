require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// OAuth token exchange route
app.post('/clio/exchange', async (req, res) => {
  const { code } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'Missing code' });
  }

  try {
    const params = new URLSearchParams();
    params.append('grant_type', 'authorization_code');
    params.append('code', code);
    params.append('client_id', process.env.CLIO_CLIENT_ID);
    params.append('client_secret', process.env.CLIO_CLIENT_SECRET);
    params.append('redirect_uri', process.env.CLIO_REDIRECT_URI);

    const response = await axios.post('https://app.clio.com/oauth/token', params, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });

    res.json(response.data);
  } catch (error) {
    console.error('Clio token exchange error:', error.response?.data || error.message);
    res.status(500).json({ error: 'Token exchange failed', details: error.response?.data || error.message });
  }
});

// Clio API proxy route
app.post('/clio/api', async (req, res) => {
  const { endpoint, method = 'GET', body, access_token } = req.body;
  if (!endpoint || !access_token) {
    return res.status(400).json({ error: 'Missing endpoint or access_token' });
  }

  try {
    const url = `https://app.clio.com/api/v4/${endpoint}`;
    console.log('=== Clio API Request ===');
    console.log('URL:', url);
    console.log('Method:', method);
    console.log('Headers:', {
      'Authorization': `Bearer ${access_token.substring(0, 10)}...`,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });
    console.log('Body:', JSON.stringify(body, null, 2));
    
    const clioResponse = await axios({
      url,
      method,
      headers: {
        'Authorization': `Bearer ${access_token}`,
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      data: body
    });
    
    console.log('=== Clio API Response ===');
    console.log('Status:', clioResponse.status);
    console.log('Data:', JSON.stringify(clioResponse.data, null, 2));
    
    res.json(clioResponse.data);
  } catch (error) {
    console.error('=== Clio API Error ===');
    console.error('Error:', error.message);
    console.error('Response Status:', error.response?.status);
    console.error('Response Data:', JSON.stringify(error.response?.data, null, 2));
    console.error('Response Headers:', error.response?.headers);
    
    res.status(500).json({ 
      error: 'Clio API request failed', 
      details: error.response?.data || error.message,
      status: error.response?.status
    });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Clio OAuth backend listening on port ${PORT}`);
}); 