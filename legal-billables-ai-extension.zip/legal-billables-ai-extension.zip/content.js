// content.js

let typingTimer;
let lastTypedTime = null;

console.log("[Legal Billables AI] content.js loaded and running on Gmail");

// Track when email is sent to capture the actual typing time
document.addEventListener("click", (event) => {
  // Look for Gmail send button
  if (event.target && (
    event.target.getAttribute("aria-label") === "Send ‪(Ctrl-Enter)‬" ||
    event.target.textContent === "Send" ||
    event.target.closest('[aria-label="Send ‪(Ctrl-Enter)‬"]')
  )) {
    console.log("📤 Send button clicked - capturing typing time...");
    
    // Try multiple ways to find the compose body
    let composeBody = null;
    let elapsedTime = 0;
    
    // Method 1: Look in the same dialog
    const dialog = event.target.closest('div[role="dialog"]');
    if (dialog) {
      composeBody = dialog.querySelector('div[aria-label="Message Body"]');
      if (composeBody && composeBody._elapsedTime) {
        elapsedTime = composeBody._elapsedTime;
      }
    }
    
    // Method 2: Look for any compose body with elapsed time
    if (!composeBody || !elapsedTime) {
      const allComposeBodies = document.querySelectorAll('div[aria-label="Message Body"]');
      for (const body of allComposeBodies) {
        if (body._elapsedTime) {
          composeBody = body;
          elapsedTime = body._elapsedTime;
          break;
        }
      }
    }
    
    // Method 3: Look for any element with _elapsedTime
    if (!elapsedTime) {
      const elementsWithTimer = document.querySelectorAll('*');
      for (const element of elementsWithTimer) {
        if (element._elapsedTime) {
          elapsedTime = element._elapsedTime;
          composeBody = element;
          break;
        }
      }
    }
    
    console.log("🔍 Found compose body:", composeBody);
    console.log("⏱️ Elapsed time:", elapsedTime);
    
    if (composeBody && elapsedTime) {
      const actualTimeSpent = elapsedTime / 1000 / 60 / 60; // Convert to hours
      
      // Try multiple methods to capture email content
      let emailContent = "";
      
      // Method 1: Try innerText
      emailContent = composeBody.innerText || "";
      
      // Method 2: Try textContent if innerText is empty
      if (!emailContent.trim()) {
        emailContent = composeBody.textContent || "";
      }
      
      // Method 3: Try querying for editable content
      if (!emailContent.trim()) {
        const editableElements = composeBody.querySelectorAll('[contenteditable="true"]');
        for (const element of editableElements) {
          const text = element.innerText || element.textContent || "";
          if (text.trim()) {
            emailContent = text;
            break;
          }
        }
      }
      
      // Method 4: Try looking for the actual email body
      if (!emailContent.trim()) {
        const emailBody = composeBody.querySelector('[role="textbox"]') || 
                         composeBody.querySelector('[contenteditable="true"]') ||
                         composeBody.querySelector('div[data-tooltip]');
        if (emailBody) {
          emailContent = emailBody.innerText || emailBody.textContent || "";
        }
      }
      
      const recipients = extractRecipients();
      
      console.log("📧 Email content captured:", emailContent);
      console.log("📧 Email content length:", emailContent.length);
      
      const data = {
        emailContent,
        recipients,
        timeSpent: parseFloat(actualTimeSpent.toFixed(4)), // 4 decimal places for precision
      };
      
      console.log("📤 Sending billable email data with actual typing time:", data);
      chrome.runtime.sendMessage({
        type: "BILLABLE_EMAIL_SENT",
        data,
      });
    } else {
      console.log("⚠️ Could not find compose body or elapsed time");
      console.log("🔍 Available compose bodies:", document.querySelectorAll('div[aria-label="Message Body"]').length);
      console.log("🔍 Elements with _elapsedTime:", Array.from(document.querySelectorAll('*')).filter(el => el._elapsedTime).length);
    }
  }
});

function extractRecipients() {
  // Try to find recipient emails from Gmail compose window
  const toField = document.querySelector('textarea[name="to"]');
  if (toField && toField.value) {
    return toField.value.split(',').map(e => e.trim()).filter(Boolean);
  }
  // Fallback: return dummy
  return ["sijy400@gmail.com"];
}

// Listen for billable email log confirmation and show a pop-up
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "BILLABLE_EMAIL_LOGGED" && message.success) {
    showGmailConfirmationPopup(`Logged ${message.hours || 'X'} hr to ${message.clientName || 'Client'}`);
  } else if (message.type === "BILLABLE_EMAIL_LOGGED" && !message.success) {
    showGmailConfirmationPopup(`Failed to log billable email${message.error ? ': ' + message.error : ''}`);
  }
});

function showGmailConfirmationPopup(text) {
  // Remove any existing pop-up
  const oldPopup = document.getElementById('legal-billables-popup');
  if (oldPopup) oldPopup.remove();

  const popup = document.createElement('div');
  popup.id = 'legal-billables-popup';
  popup.textContent = text;
  popup.style.cssText = `
    position: fixed;
    top: 80px;
    right: 40px;
    background: #1a73e8;
    color: #fff;
    padding: 14px 28px;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 500;
    box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    z-index: 99999;
    opacity: 0;
    transition: opacity 0.3s;
  `;
  document.body.appendChild(popup);
  setTimeout(() => { popup.style.opacity = '1'; }, 10);
  setTimeout(() => {
    popup.style.opacity = '0';
    setTimeout(() => popup.remove(), 400);
  }, 3500);
}

// Gmail Compose Timer: Tracks typing time per email (pauses on inactivity)

function formatTime(ms) {
  const s = Math.floor(ms / 1000) % 60;
  const m = Math.floor(ms / 60000);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function setupComposeTimer(composeBody) {
  if (composeBody._hasTimer) return; // Prevent double-initialization
  composeBody._hasTimer = true;
  let elapsed = 0;
  let timerInterval = null;
  let lastTyped = Date.now();
  let paused = true;
  
  // Store the elapsed time on the compose body for access when sending
  composeBody._elapsedTime = 0;

  // Create timer display
  const timerDisplay = document.createElement('span');
  timerDisplay.style.cssText = 'position:absolute;top:5px;right:10px;background:#fff;padding:2px 6px;border-radius:4px;font-size:12px;z-index:1000;box-shadow:0 1px 4px rgba(0,0,0,0.08);';
  timerDisplay.textContent = '0:00';
  // Insert timer display into the compose window
  let dialog = composeBody.closest('div[role="dialog"]');
  if (dialog) {
    dialog.style.position = 'relative';
    dialog.appendChild(timerDisplay);
  } else {
    // fallback: append to body parent
    composeBody.parentElement.appendChild(timerDisplay);
  }

  function startTimer() {
    if (timerInterval) return;
    paused = false;
    timerInterval = setInterval(() => {
      if (!paused) {
        elapsed += 1000;
        composeBody._elapsedTime = elapsed; // Update the stored elapsed time
        timerDisplay.textContent = formatTime(elapsed);
        console.log("⏱️ Timer updated - elapsed:", elapsed, "ms");
      }
    }, 1000);
  }

  function pauseTimer() {
    paused = true;
  }

  function onType() {
    lastTyped = Date.now();
    if (paused) startTimer();
    clearTimeout(composeBody._inactivityTimeout);
    composeBody._inactivityTimeout = setTimeout(() => {
      pauseTimer();
    }, 10000); // 10 seconds inactivity
  }

  composeBody.addEventListener('keydown', onType);

  // Clean up when compose is closed
  const closeObserver = new MutationObserver(() => {
    if (!document.body.contains(composeBody)) {
      clearInterval(timerInterval);
      clearTimeout(composeBody._inactivityTimeout);
      if (timerDisplay.parentElement) timerDisplay.parentElement.removeChild(timerDisplay);
      closeObserver.disconnect();
    }
  });
  closeObserver.observe(document.body, { childList: true, subtree: true });

  // Debug log
  console.log('[Gmail Compose Timer] Timer attached to compose window.');
}

// Helper: Find all open compose bodies
function findAllComposeBodies() {
  // Gmail uses div[aria-label="Message Body"] for compose body
  return Array.from(document.querySelectorAll('div[aria-label="Message Body"]'));
}

// Attach timers to all open compose windows on load
function attachTimersToAllComposes() {
  const bodies = findAllComposeBodies();
  bodies.forEach(setupComposeTimer);
  if (bodies.length === 0) {
    console.log('[Gmail Compose Timer] No compose windows found on load.');
  } else {
    console.log(`[Gmail Compose Timer] Found ${bodies.length} compose window(s) on load.`);
  }
}

// Use MutationObserver to detect new compose windows
const observer = new MutationObserver(mutations => {
  for (const m of mutations) {
    for (const node of m.addedNodes) {
      if (node.nodeType === 1) {
        // Gmail compose body is a div[aria-label="Message Body"]
        const composeBody = node.querySelector && node.querySelector('div[aria-label="Message Body"]');
        if (composeBody) {
          setupComposeTimer(composeBody);
        }
        // Also check if the node itself is a compose body
        if (node.matches && node.matches('div[aria-label="Message Body"]')) {
          setupComposeTimer(node);
        }
      }
    }
  }
});

observer.observe(document.body, { childList: true, subtree: true });

// Initial scan on load
attachTimersToAllComposes();

document.addEventListener('DOMContentLoaded', function() {
  chrome.storage.local.get(['lastSummary', 'lastTypingTime'], (result) => {
    document.getElementById('summary').textContent = result.lastSummary || 'No summary yet.';
    if (result.lastTypingTime !== undefined) {
      document.getElementById('typingTime').textContent = `${result.lastTypingTime} hr`;
    } else {
      document.getElementById('typingTime').textContent = 'No time tracked yet.';
    }
  });

  document.getElementById('logoutBtn').addEventListener('click', function() {
    chrome.storage.local.remove(['clioAccessToken', 'lastSummary', 'lastTypingTime'], () => {
      // Optionally, also clear any in-memory variables in background.js
      chrome.runtime.sendMessage({ type: 'CLIO_LOGOUT' });
      alert('You have been logged out of Clio. Please re-authenticate to continue.');
      window.close();
    });
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CLIO_LOGOUT') {
    clioAccessToken = null;
    // Optionally, clear any other session data
  }
});
