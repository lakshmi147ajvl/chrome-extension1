chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("[Legal Billables AI] background.js received message:", request);
  if (request.action === "summarizeEmail") {
    summarizeWithOpenRouter(request.emailContent).then(summary => {
      sendResponse({ summary });
    }).catch(error => {
      console.error("Summarization error:", error);
      sendResponse({ summary: "Error during summarization." });
    });
    return true; // Keeps the message channel open for async response
  }
  // NEW: Handle billable email event
  if (request.type === "BILLABLE_EMAIL_SENT") {
    (async () => {
      try {
        // 1. Summarize email content
        const summary = await summarizeWithOpenRouter(request.data.emailContent);
        // 2. Lookup client/case in Clio (stub)
        const clientId = await lookupClioClient(request.data.recipients);
        // 3. Log time entry in Clio (stub)
        const logResult = await logClioTimeEntry({
          clientId,
          summary,
          timeSpent: request.data.timeSpent,
          emailContent: request.data.emailContent,
          recipients: request.data.recipients
        });
        sendResponse({ success: true, summary, logResult });
        // Store summary and typing time for popup
        chrome.storage.local.set({
          lastSummary: summary,
          lastTypingTime: request.data.timeSpent,
          lastDate: (new Date()).toISOString().slice(0, 10),
          lastEmail: (request.data.recipients && request.data.recipients.join(', ')) || '-'
        });
        console.log("[Legal Billables AI] 💾 Stored summary in extension popup:", summary);
        // NEW: Notify content script for UI feedback
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
              type: "BILLABLE_EMAIL_LOGGED",
              success: true,
              summary,
              hours: request.data.timeSpent,
              clientName: logResult && logResult.clientName // if available
            });
          }
        });
      } catch (error) {
        console.error("Billable email logging error:", error);
        sendResponse({ success: false, error: error.message || error });
        // NEW: Notify content script for UI feedback
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
              type: "BILLABLE_EMAIL_LOGGED",
              success: false,
              error: error.message || error
            });
          }
        });
      }
    })();
    return true;
  }
  if (request.type === 'CLIO_LOGOUT') {
    clioAccessToken = null;
    // Optionally clear other session data if needed
  }
  if (request.type === 'CLIO_LOGIN') {
    authenticateWithClio(true);
  }
});

async function summarizeWithOpenRouter(text) {
  const apiKey = "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"; // 🔁 Replace with your actual key
  const url = "https://openrouter.ai/api/v1/chat/completions";

  // Check if text is empty or too short
  if (!text || text.trim().length < 10) {
    return "Email composition time logged - content was minimal or empty.";
  }

  const payload = {
    model: "openai/gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are a helpful legal assistant. Summarize the email content clearly for legal billing purposes. If the content is minimal, provide a brief description of the email type or purpose."
      },
      {
        role: "user",
        content: text
      }
    ]
  };

  const headers = {
    "Authorization": `Bearer ${apiKey}`,
    "Content-Type": "application/json"
  };

  const response = await fetch(url, {
    method: "POST",
    headers: headers,
    body: JSON.stringify(payload)
  });

  const result = await response.json();

  if (result?.choices?.[0]?.message?.content) {
    return result.choices[0].message.content.trim();
  } else {
    console.error("OpenRouter API error:", result);
    return "No summary generated.";
  }
}

// Replace lookupClioClient with real Clio API call
async function lookupClioClient(recipients) {
  // Try to find the first matching contact by email
  await authenticateWithClio();
  for (const email of recipients) {
    const res = await clioApiRequest(`contacts?fields=id,first_name,last_name,email_addresses&query=${encodeURIComponent(email)}`);
    if (res && res.data && res.data.length > 0) {
      // Return the first matching contact's ID
      return res.data[0].id;
    }
  }
  throw new Error("No matching Clio contact found for recipients: " + recipients.join(", "));
}

// Replace logClioTimeEntry with real Clio API call
async function logClioTimeEntry({ clientId, summary, timeSpent, emailContent, recipients }) {
  await authenticateWithClio();
  // First, get a valid matter_id from the user's Clio account
  let matterId = null;
  try {
    const mattersResponse = await clioApiRequest("matters", "GET");
    if (mattersResponse && mattersResponse.data && mattersResponse.data.length > 0) {
      matterId = mattersResponse.data[0].id; // Use the first available matter
      console.log("[Legal Billables AI] Using matter_id:", matterId);
    } else {
      throw new Error("No matters found in Clio account");
    }
  } catch (error) {
    console.error("[Legal Billables AI] Error getting matters:", error);
    throw new Error("Failed to get matter from Clio");
  }

  // Build a detailed description from all popup fields
  const formattedDescription =
    `Billable Email Details:\n` +
    `Date: ${(new Date()).toISOString().slice(0, 10)}\n` +
    `Recipients: ${(recipients && recipients.join(', ')) || '-'}\n` +
    `Summary:\n${summary}\n` +
    `Time Taken: ${timeSpent} hr`;

  // Build the activity payload
  const activityEntry = {
    data: {
      date: new Date().toISOString().slice(0, 10),
      quantity: Math.round(timeSpent * 3600), // Convert hours to seconds
      price: 200, // Default hourly rate
      type: "TimeEntry",
      matter_id: matterId,
      description: summary, // Only summary here
      note: formattedDescription // Full details in note
    }
  };

  try {
    console.log("[Legal Billables AI] Sending activity to /activities endpoint:", JSON.stringify(activityEntry, null, 2));
    const res = await clioApiRequest("activities", "POST", activityEntry);
    console.log("[Legal Billables AI] Activities endpoint response:", JSON.stringify(res, null, 2));
    if (res && res.data && res.data.id) {
      console.log("[Legal Billables AI] ✅ Successfully created activity with ID:", res.data.id);
      // Automatically fetch the created activity to verify the description
      try {
        const retrievedEntry = await clioApiRequest(`activities/${res.data.id}`, "GET");
        console.log("[Legal Billables AI] 📋 Retrieved activity details:", JSON.stringify(retrievedEntry, null, 2));
        if (retrievedEntry && retrievedEntry.data && typeof retrievedEntry.data.description !== 'undefined') {
          console.log("[Legal Billables AI] 🔎 Description field in API:", retrievedEntry.data.description);
        } else {
          console.warn("[Legal Billables AI] ⚠️ Description field not found in API response.");
        }
      } catch (retrieveError) {
        console.log("[Legal Billables AI] Could not retrieve activity details:", retrieveError);
      }
      return { entryId: res.data.id, matterId: matterId, method: "activities" };
    }
  } catch (error) {
    console.log("[Legal Billables AI] Activities endpoint failed:", error);
  }
  throw new Error("Failed to create activity time entry");
}

// Function to update the description of an existing time entry (activity) by ID
async function updateClioTimeEntryDescription(activityId, newDescription) {
  await authenticateWithClio();
  const updatePayload = {
    data: {
      description: newDescription
    }
  };
  try {
    console.log(`[Legal Billables AI] PATCH /activities/${activityId} with description:`, newDescription);
    const res = await clioApiRequest(`activities/${activityId}`, "PATCH", updatePayload);
    console.log(`[Legal Billables AI] PATCH response:`, JSON.stringify(res, null, 2));
    return res;
  } catch (error) {
    console.error(`[Legal Billables AI] Failed to update description for activity ${activityId}:`, error);
    throw error;
  }
}

// === Clio OAuth2 Authentication and Token Management ===
const CLIO_CLIENT_ID = "TAZs3Qyglh4A5xygvHXH8a7BUAjwASXD3WCXCwXI";
const CLIO_AUTH_URL = "https://app.clio.com/oauth/authorize";
const CLIO_TOKEN_URL = "https://app.clio.com/oauth/token";
const CLIO_REDIRECT_URI = "https://icehpabbfbhbkdcoahilekbkkddcbinf.chromiumapp.org/";
const CLIO_SCOPES = [
  "openid",
  "profile",
  "email",
  "read:users",
  "read:contacts",
  "write:time_entries"
].join(" ");

let clioAccessToken = null;

// Load token from storage on startup
chrome.storage.local.get('clioAccessToken', (result) => {
  if (result.clioAccessToken) {
    clioAccessToken = result.clioAccessToken;
    console.log('[Legal Billables AI] Loaded Clio access token from storage.');
  }
});

function authenticateWithClio(force = false) {
  return new Promise((resolve, reject) => {
    if (clioAccessToken && !force) {
      // Already have token
      resolve(clioAccessToken);
      return;
    }
    const authUrl = `${CLIO_AUTH_URL}?response_type=code&client_id=${encodeURIComponent(CLIO_CLIENT_ID)}&redirect_uri=${encodeURIComponent(CLIO_REDIRECT_URI)}&scope=${encodeURIComponent(CLIO_SCOPES)}`;
    console.log("[Legal Billables AI] Clio OAuth authUrl:", authUrl);
    chrome.identity.launchWebAuthFlow(
      {
        url: authUrl,
        interactive: true
      },
      async function(redirectUrl) {
        if (chrome.runtime.lastError || !redirectUrl) {
          console.error("[Legal Billables AI] OAuth failed:", chrome.runtime.lastError, redirectUrl);
          reject(new Error("Auth failed"));
          return;
        }
        // Extract code from redirectUrl
        const url = new URL(redirectUrl);
        const code = url.searchParams.get("code");
        if (!code) {
          reject(new Error("No code returned"));
          return;
        }
        // Exchange code for token via backend proxy
        try {
          const backendUrl = "http://localhost:3001/clio/exchange";
          const res = await fetch(backendUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code })
          });
          const data = await res.json();
          if (data.access_token) {
            clioAccessToken = data.access_token;
            // Persist token in storage
            chrome.storage.local.set({ clioAccessToken: clioAccessToken });
            resolve(clioAccessToken);
          } else {
            console.error("[Legal Billables AI] Backend token exchange failed:", data);
            reject(new Error("No access token in backend response"));
          }
        } catch (err) {
          console.error("[Legal Billables AI] Error contacting backend for token exchange:", err);
          reject(new Error("Backend token exchange failed"));
        }
      }
    );
  });
}

async function refreshClioToken(refreshToken) {
  const res = await fetch(CLIO_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(refreshToken)}&client_id=${encodeURIComponent(CLIO_CLIENT_ID)}&client_secret=${encodeURIComponent(CLIO_CLIENT_SECRET)}&redirect_uri=${encodeURIComponent(CLIO_REDIRECT_URI)}`
  });
  const data = await res.json();
  if (data.access_token) {
    await setStoredClioTokens(data);
    return data;
  } else {
    throw new Error("Failed to refresh token");
  }
}

async function clioApiRequest(endpoint, method = "GET", body = null, queryParams = null) {
  // Always try to load token from storage if not in memory
  if (!clioAccessToken) {
    await new Promise((resolve) => {
      chrome.storage.local.get('clioAccessToken', (result) => {
        if (result.clioAccessToken) {
          clioAccessToken = result.clioAccessToken;
        }
        resolve();
      });
    });
  }
  if (!clioAccessToken) {
    await authenticateWithClio();
  }
  
  // Add query parameters to endpoint if provided
  let fullEndpoint = endpoint;
  if (queryParams) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(queryParams)) {
      params.append(key, value);
    }
    fullEndpoint = `${endpoint}?${params.toString()}`;
  }
  
  const backendUrl = "http://localhost:3001/clio/api";
  const res = await fetch(backendUrl, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${clioAccessToken}`,
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify({
      endpoint: fullEndpoint,
      method,
      body,
      access_token: clioAccessToken
    })
  });
  const contentType = res.headers.get("content-type");
  if (contentType && contentType.includes("application/json")) {
    return res.json();
  } else {
    const text = await res.text();
    throw new Error("Expected JSON, got: " + text.slice(0, 100));
  }
}
