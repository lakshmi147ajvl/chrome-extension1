document.addEventListener('DOMContentLoaded', function() {
  chrome.storage.local.get(['lastDate', 'lastEmail', 'lastSummary', 'lastTypingTime'], (result) => {
    document.getElementById('popupDate').textContent = result.lastDate || '-';
    document.getElementById('popupEmail').textContent = result.lastEmail || '-';
    document.getElementById('popupSummary').textContent = result.lastSummary || 'No summary yet.';
    if (result.lastTypingTime !== undefined) {
      document.getElementById('popupTime').textContent = `${result.lastTypingTime} hr`;
    } else {
      document.getElementById('popupTime').textContent = '-';
    }
  });

  // Add logout button handler
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function() {
      chrome.storage.local.remove(['clioAccessToken', 'lastSummary', 'lastTypingTime', 'lastDate', 'lastEmail'], () => {
        chrome.runtime.sendMessage({ type: 'CLIO_LOGOUT' }, () => {
          // After logout, immediately trigger login
          chrome.runtime.sendMessage({ type: 'CLIO_LOGIN' });
          alert('You have been logged out of Clio. Please re-authenticate to continue.');
          window.close();
        });
      });
    });
  }
});
